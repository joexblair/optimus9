"""
PKSignalDetector — orchestrates state computation + gating + transition
detection to produce per-pool signals.

REPLACES the per-bar PKDetector. Key semantic change:

  OLD (PKDetector, per-bar):
    Every bar where (state ≠ 0) AND (gate matches) emits a signal.
    Trends produce N consecutive signals over N bars.

  NEW (PKSignalDetector, transition):
    A signal fires only when state TRANSITIONS into a new directional
    value (non-zero and different from previous bar's state).
    Trends produce ONE signal at the trend's start.

Rationale: 5s signals are anchor points for HTF p-rev logic, not per-bar
re-evaluations of the same trend. A trend in one direction is a single
anchor opportunity, not N redundant ones.

Same interface as PKDetector.detect() for downstream compatibility:
returns list of signal dicts with the same keys.
"""

from typing import Optional

import numpy as np

from logger import get_logger
from .pk_state_computer import PKStateComputer
from .pk_gate_filter   import PKGateFilter


class PKSignalDetector:
    """Detect PK transition signals across close and wide pools, gate-aware."""

    def __init__(self,
                 state_computer: Optional[PKStateComputer] = None,
                 gate_filter:    Optional[PKGateFilter]    = None) -> None:
        self._state_computer = state_computer or PKStateComputer()
        self._gate_filter    = gate_filter    or PKGateFilter()
        self._log            = get_logger(self.__class__.__name__)

    def detect(self, line: np.ndarray, dema: np.ndarray,
               pool_c: int, pool_w: int, pool_range: int,
               multiplier: int, slope_floor: float,
               oob_side: np.ndarray, params: dict,
               line_type: str = 'bb') -> list:
        """
        Return list of signal dicts. Compatible with PKDetector.detect()'s
        contract — same signal dict keys, suitable for _persist_gated.
        """
        if pool_range == 0:
            return []

        signals = []
        for label, bars in (('close', pool_c), ('wide', pool_w)):
            state_series = self._state_computer.compute(
                line, dema, bars, pool_range, multiplier, slope_floor,
            )
            half   = pool_range // 2
            upper  = (bars + half) * multiplier
            center = bars * multiplier

            prev_state = 0.0
            for i in range(upper, len(line)):
                cur_state = state_series[i]

                if np.isnan(cur_state):
                    prev_state = 0.0
                    continue

                # Transition check: current is non-zero AND differs from previous
                # (or previous was 0). State going from -1 to +2 also counts —
                # any change into a directional non-zero state is a transition.
                is_transition = (cur_state != prev_state) and (cur_state != 0.0)

                if is_transition and self._gate_filter.passes(cur_state, int(oob_side[i])):
                    signals.append(self._build_signal(
                        i=i, label=label, bars=bars,
                        cur_state=cur_state,
                        line=line, dema=dema, center=center,
                        pool_c=pool_c, pool_w=pool_w, pool_range=pool_range,
                        slope_floor=slope_floor, multiplier=multiplier,
                        oob_side=int(oob_side[i]),
                        params=params, line_type=line_type,
                    ))

                prev_state = cur_state

        return signals

    # ── Signal dict construction ─────────────────────────────────────────────

    def _build_signal(self, i: int, label: str, bars: int,
                      cur_state: float,
                      line: np.ndarray, dema: np.ndarray, center: int,
                      pool_c: int, pool_w: int, pool_range: int,
                      slope_floor: float, multiplier: int,
                      oob_side: int,
                      params: dict, line_type: str) -> dict:
        """Build signal dict matching PKDetector's output shape."""
        # Recompute slope details at the signal bar — needed for the dict.
        # (We could thread these through compute(), but it's cleaner to keep
        # PKStateComputer pure and recompute the few values we persist here.)
        half  = pool_range // 2
        upper = (bars + half) * multiplier
        lower = (bars - half) * multiplier

        window = line[i - upper + 1 : i - lower + 1]
        peak   = np.max(window) if line[i] > self._state_computer._midpoint else np.min(window)

        line_slope  = float(line[i] - peak)
        price_slope = float(dema[i] - dema[i - center])
        slope_diff  = abs(line_slope - price_slope)

        expected = self._gate_filter.direction(oob_side)

        sig = {
            'bar_index':   i,
            'direction':   expected,
            'pk_state':    cur_state,
            'line_value':  float(line[i]),
            'slope':       line_slope,
            'slope_diff':  slope_diff,
            'dema_slope':  price_slope,
            'dema_value':  float(dema[i]),
            'pool':        label,
            'len':         params['len'],
            'src':         params['src'],
            'pool_c':      pool_c,
            'pool_w':      pool_w,
            'pool_range':  pool_range,
            'slope_floor': slope_floor,
            'multiplier':  multiplier,
        }

        if line_type == 'bb':
            sig['mult'] = params['mult']
        else:  # 'k'
            sig['len_rsi']   = params['len_rsi']
            sig['len_stoch'] = params['len_stoch']

        return sig
