-- r05_260520 slope_floor sub-60 diagnostic
-- ============================================================================
-- After bny30 gating, all 6 lines converged on slope_floor=90 as optimum
-- within the 60-180 grid. But the grid bottoms at 60 — we don't know if
-- 30 or 45 is alive post-gating. This sweep probes 15-90.
--
-- Locks all other params at gcs5m's PROVEN combo (Stage 2 #1, AM v2). Run
-- on a 15-day window for sample mass.
--
-- NOTE on PROVEN params: gcs5m's PROVEN combo from or_pk=22 needs to be
-- extracted via validate_centroid first. The values below are placeholders
-- based on the centroid (len=9, pool_c=33, pool_w=78, pool_range=5).
-- Joe: update these to the actual PROVEN values from validate_or22.csv
-- before running.
--
-- Grid: slope_floor 15→90 step 15 = 6 values
-- All other params locked = 6 combos total
-- Runtime: ~2 minutes on 15-day window
-- ============================================================================

START TRANSACTION;

INSERT INTO test_configs (
    tc_tp_pk, tc_ic_pk, tc_indicator_label,
    tc_dema_len, tc_dema_src, tc_stop_pct, tc_dynamic_stoploss,
    tc_stop_buffer, tc_profit_zone, tc_drag_pct, tc_max_bars
)
SELECT tc_tp_pk, tc_ic_pk, 'gcs5m_slope_sub60_diag',
       tc_dema_len, tc_dema_src,
       0.71, 0, tc_stop_buffer,
       tc_profit_zone, tc_drag_pct, tc_max_bars
FROM test_configs WHERE tc_indicator_label = 'gcs5m_wide_gated' LIMIT 1;

SET @sf_tc := LAST_INSERT_ID();

-- bny30 AND gating active (same as wide_gated)
INSERT INTO test_config_extensions
    (tce_tc_pk, tce_type, tce_ic_pk, tce_is_active, tce_sort_order)
VALUES
    (@sf_tc, 'gate', 2, 1, 1),
    (@sf_tc, 'gate', 3, 1, 2);

-- All params locked at gcs5m PROVEN combo (UPDATE THESE from validate_or22.csv)
-- slope_floor: curr=52.5, step=15, range=75 → n=5, half=2.5... need even n
-- Use curr=45, step=15, range=90 → 7 vals from -45 to +45... that gives 15,30,45,60,75,90 step 15 = 7 vals? Let's check
-- n = round(90/15) = 6 (even), half=3, values = 45 + [-45, -30, -15, 0, 15, 30, 45] = 0, 15, 30, 45, 60, 75, 90 — 7 vals
-- We want NO zero (filtered by positive). And we want 6 vals: 15, 30, 45, 60, 75, 90.
-- curr=52.5, step=15, range=75 → n=5 (odd, no good)
-- curr=45, step=15, range=75 → n=5 (odd)
-- curr=52.5, step=15, range=90 → n=6 (even), half=3, values 7.5, 22.5, 37.5, 52.5, 67.5, 82.5, 97.5 — not clean
-- 
-- Cleanest: use 5 vals 30→90 step 15 (centered 60, range 60): values 30, 45, 60, 75, 90
-- or 7 vals including 15: curr=52.5 step=15 range=90 → 7.5, 22.5, ... not clean integers
-- 
-- Going with 5 vals: 30, 45, 60, 75, 90. If 30 looks alive we extend lower in r06.

INSERT INTO test_param_ranges
    (tpr_tc_pk, tpr_param_name, tpr_current_value, tpr_step, tpr_range,
     tpr_enum_values, tpr_param_type)
VALUES
    -- !!! UPDATE these line + pool values from validate_or22.csv after run !!!
    (@sf_tc, 'len',               8.0,   0.0,  0.0,   NULL,    'int'),
    (@sf_tc, 'mult',              0.74,  0.0,  0.0,   NULL,    'float'),
    (@sf_tc, 'src',               NULL,  NULL, NULL,  'close', 'enum'),
    (@sf_tc, 'pool_c',            34.0,  0.0,  0.0,   NULL,    'int'),
    (@sf_tc, 'pool_w',            70.0,  0.0,  0.0,   NULL,    'int'),
    (@sf_tc, 'pool_range',        4.0,   0.0,  0.0,   NULL,    'int'),
    -- slope_floor: curr=60, step=15, range=60 → 5 values: 30, 45, 60, 75, 90
    (@sf_tc, 'slope_floor',       60.0,  15.0, 60.0,  NULL,    'float'),
    (@sf_tc, 'multiplier',        1.0,   0.0,  0.0,   NULL,    'int'),
    (@sf_tc, 'tcev_weight_close', 5.0,   0.0,  0.0,   NULL,    'int'),
    (@sf_tc, 'tcev_weight_wide',  2.0,   0.0,  0.0,   NULL,    'int');

COMMIT;

SELECT @sf_tc AS new_tc_pk,
       'gcs5m_slope_sub60_diag' AS label,
       5 AS expected_combos;

-- After running on 15-day window:
--   - If slope_floor=30 produces meaningful signals with exp > 0.5% → 
--     widen future grids to include sub-60 range
--   - If slope_floor=30 collapses (<30 signals or exp < 0) → 
--     lock 60 as the lower bound, current grid range is correct
