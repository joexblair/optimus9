-- r05_260520 gca5M wide-gated grind — new slow BB line
-- ============================================================================
-- Replaces gca5m (ultra-fast BB, len=6) which was redundant with gcs5m.
-- New baseline: len=55, mult=0.92, src=ohlc4 — a slow BB sitting between
-- gcs5m (len=12 medium) and gcb5M (len=40 slow trend).
--
-- Same shape as the existing wide_6line BB grids:
--   len(7) × mult(1) × src(5) × pool_c(13) × pool_w(11) × pool_range(3) × slope_floor(5)
--   = 75,075 combos
--
-- bny30 AND-gated, stop=0.71. Runs at ~20K combos/hr → ~3.75hr.
--
-- ic_pk for gca5M: assumes the indicator_configs row exists. If not,
-- it needs to be added first via:
--   INSERT INTO indicator_configs (ic_line_type, ic_src, ic_bb_len,
--   ic_bb_mult, ic_high_boundary, ic_low_boundary, ic_itf_pk, ic_is_pk, ic_il_pk)
--   VALUES ('bb', 'ohlc4', 55, 0.92, 85, 15, <5s_itf>, <bb_is>, <gca_il>);
-- Joe: confirm the ic_pk before running this SQL.
-- ============================================================================

-- IMPORTANT: set this to the gca5M ic_pk after creating the indicator_configs row.
-- If gca5M already exists in indicator_configs, find its ic_pk:
--   SELECT ic_pk FROM indicator_configs WHERE ic_bb_len=55 AND ic_bb_mult=0.92;
SET @gca5M_ic_pk := NULL;  -- !!! REPLACE WITH ACTUAL ic_pk !!!

START TRANSACTION;

INSERT INTO test_configs (
    tc_tp_pk, tc_ic_pk, tc_indicator_label,
    tc_dema_len, tc_dema_src, tc_stop_pct, tc_dynamic_stoploss,
    tc_stop_buffer, tc_profit_zone, tc_drag_pct, tc_max_bars
)
VALUES (1, @gca5M_ic_pk, 'gca5M_wide_gated', 2, 'close', 0.71, 0,
        0.05, 0.60, 0.00, 1080);
SET @tc := LAST_INSERT_ID();

INSERT INTO test_config_extensions
    (tce_tc_pk, tce_type, tce_ic_pk, tce_is_active, tce_sort_order)
VALUES
    (@tc, 'gate', 2, 1, 1),
    (@tc, 'gate', 3, 1, 2);

-- BB line wide grid:
-- len:        curr=55, step=2, range=12 → 7 vals: 49,51,53,55,57,59,61
-- mult:       0.92 (fixed)
-- src:        all 5 enums
-- pool_c:     curr=32, step=2, range=24 → 13 vals: 20→44
-- pool_w:     curr=70, step=5, range=50 → 11 vals: 45→95
-- pool_range: curr=4, step=2, range=4 → 3 vals: 2,4,6
-- slope_floor: curr=120, step=30, range=120 → 5 vals: 60,90,120,150,180
-- multiplier: 1 (fixed)
-- Total: 7 × 5 × 13 × 11 × 3 × 5 = 75,075 combos

INSERT INTO test_param_ranges
    (tpr_tc_pk, tpr_param_name, tpr_current_value, tpr_step, tpr_range,
     tpr_enum_values, tpr_param_type)
VALUES
    (@tc, 'len',               55.0,  2.0,  12.0,  NULL,                              'int'),
    (@tc, 'mult',              0.92,  0.0,  0.0,   NULL,                              'float'),
    (@tc, 'src',               NULL,  NULL, NULL,  'close,hl2,hlc3,hlcc4,ohlc4',     'enum'),
    (@tc, 'pool_c',            32.0,  2.0,  24.0,  NULL,                              'int'),
    (@tc, 'pool_w',            70.0,  5.0,  50.0,  NULL,                              'int'),
    (@tc, 'pool_range',        4.0,   2.0,  4.0,   NULL,                              'int'),
    (@tc, 'slope_floor',       120.0, 30.0, 120.0, NULL,                              'float'),
    (@tc, 'multiplier',        1.0,   0.0,  0.0,   NULL,                              'int'),
    (@tc, 'tcev_weight_close', 5.0,   0.0,  0.0,   NULL,                              'int'),
    (@tc, 'tcev_weight_wide',  2.0,   0.0,  0.0,   NULL,                              'int');

COMMIT;

SELECT @tc AS new_tc_pk,
       'gca5M_wide_gated' AS label,
       75075 AS expected_combos;
