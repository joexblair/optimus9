"""
PKStateComputer — pure PK state computation per bar.

Vectorized numpy implementation. Computes pk_state values per bar based
on line vs DEMA slope analysis. Matches Pine's f_pk_state exactly:

  - Peak window: line[i - upper + 1 : i - lower + 1]
    (Pine: ta.highest(line[lower], window_size) — same set of bars)
  - slope_diff <= slope_floor → state 0 (neutral)
  - sign disagreement → state ±1 (divergence)
  - sign agreement → state ±2 (PM sentinel)

Note (r07/r08):
  The high_b / low_b boundary defaults are currently set per-indicator-config
  in MySQL (indicator_configs table) but every row is 85/15. These are global
  system constants and should move to a system_settings table. Until then,
  PKStateComputer's constructor takes them as args for testability; production
  callers pass the per-config values.
"""

import numpy as np

from logger import get_logger


class PKStateComputer:
    """Pure math: compute pk_state per bar for a single pool config."""

    _PM_LONG  =  2.0
    _PM_SHORT = -2.0

    def __init__(self, high_b: float = 85.0, low_b: float = 15.0) -> None:
        # r08: high_b/low_b should be global system settings. See module docstring.
        self._midpoint = (high_b + low_b) / 2.0
        self._log      = get_logger(self.__class__.__name__)

    def compute(self, line: np.ndarray, dema: np.ndarray,
                bars: int, pool_range: int,
                multiplier: int, slope_floor: float) -> np.ndarray:
        """
        Return ndarray of pk_state values, length == len(line).

        Values:
          NaN  — not yet computable (insufficient lookback)
          0    — neutral (slope_diff under floor)
          ±1   — divergence (line and price slopes disagree on sign)
          ±2   — PM sentinel (slopes agree on sign with significant magnitude)
        """
        n = len(line)
        states = np.full(n, np.nan, dtype=np.float64)

        if pool_range == 0:
            return states

        half   = pool_range // 2
        lower  = (bars - half) * multiplier
        upper  = (bars + half) * multiplier
        center = bars * multiplier

        # Pine-aligned window: line[i - upper + 1 : i - lower + 1]
        # This is one bar narrower than the OG PKDetector window (which used
        # i - upper : i - lower + 1). Pk5sGateComputer already uses this
        # narrower form; PKStateComputer matches it for full Pine parity.

        for i in range(upper, n):
            if np.isnan(line[i]) or np.isnan(dema[i]) or np.isnan(dema[i - center]):
                continue

            window = line[i - upper + 1 : i - lower + 1]
            if not len(window):
                continue

            peak = np.max(window) if line[i] > self._midpoint else np.min(window)

            line_slope  = float(line[i] - peak)
            price_slope = float(dema[i] - dema[i - center])

            if np.isnan(line_slope) or np.isnan(price_slope):
                continue

            slope_diff = abs(line_slope - price_slope)

            if slope_diff <= slope_floor:
                states[i] = 0.0
                continue

            if np.sign(line_slope) != np.sign(price_slope):
                states[i] = 1.0 if line_slope > 0 else -1.0
            else:
                states[i] = self._PM_LONG if line_slope > 0 else self._PM_SHORT

        return states
